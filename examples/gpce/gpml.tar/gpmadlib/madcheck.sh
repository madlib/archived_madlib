#!/bin/bash

#Check to see if the DB is available
DBUP=`2>/dev/null psql gpmldemo -t -c "SELECT 1"`
RETVAL=$?

if [ $RETVAL -ne 0 ] || [ $DBUP -ne 1 ]; then
  ../bin/execute-window.sh 'echo' 'Database gpmldemo does not exist. It will be created...'
  createdb gpmldemo
  psql gpmldemo -c "create schema madlib;"
  psql gpmldemo -c "create language plpgsql;"
  psql gpmldemo -c "create language plpythonu;"
  madpack update
fi

