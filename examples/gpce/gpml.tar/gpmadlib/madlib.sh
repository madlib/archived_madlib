#!/bin/bash

rm -rf ./madlib.out

function run_method {
RUNTIME=`2>&1 time -p psql -d gpmldemo -f $1.sql >> madlib.out | grep real | awk '{ print $2 }'`
  RETVAL=$?
  if [ $RETVAL -ne 0 ]; then
    printf "Error running MADlib examples, exiting...\n"; exit 1
  fi
printf ' done in %f seconds.\n' $RUNTIME ;
}

printf '\nRunning (Multi-)Linear Regression... ' 
run_method multi-lin-regress

printf '\nRunning Logistic Regression... ' 
run_method logistic-regress

printf '\nRunning Support Vector Machines methods (regression, clasification, novelty detection)... ' 
run_method svm

printf '\nRunning k-Means Clustering... ' 
run_method kmeans

printf '\nRunning Sketches (Fast Data Profiling) ... ' 
run_method sketches

printf '\nRunning Naive-Bayes Classification... ' 
run_method naive-bayes

printf '\nRunning SVD Matrix Factorisation... ' 
run_method svd-mf

printf '\nAll MADlib examples finished. \nResults are in the file %s\n\n' `pwd`/madlib.out
